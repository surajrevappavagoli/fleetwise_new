# AWS IoT FleetWise Cloud Demo Script

## Prerequisites

The demo applies for Python 3.8+ environment. Install the dependencies:

```bash
sudo ./install-deps.sh
```

## Running the Demo

Run the demo:

```bash
./demo.sh
```
